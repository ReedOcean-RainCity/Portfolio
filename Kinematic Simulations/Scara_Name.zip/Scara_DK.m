function [T01,T02,T02p,T03,T04] = Scara_DK(L1,L2,L3,d4,t1,t2,t4)

T01 = rawTabs(0, 0, L1, t1);
T12 = rawTabs(L2, 0, 0, t2);
T22p = rawTabs(L3, 0, 0, 0);
T2p3 = rawTabs(0, 0, d4, 0);
T34 = rawTabs(0, pi, 0, t4);

T02 = T01*T12;
T02p = T02*T22p;
T03 = T02p*T2p3;
T04 = T03*T34;
end