function [a0,a2,a3] = calcTrajCo(AposF,AposI,travTim)

a0 = AposI;

a1=0;

a3 = -2*(AposF-AposI)*(1/(travTim**3));

a2 = (-3/2)*a3*travTim;
end