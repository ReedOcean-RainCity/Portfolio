function [] = DrawScara(T01,T02,T02p,T03,T04,pEE)
  %set canvas
  figure(1);
  clf(1);
  hold on;  grid;
  %calculate points
  p0 = [0; 0;0];
  p1 = [T01(1, 4); T01(2, 4);T01(3, 4)];
  p2 = [T02(1, 4); T02(2, 4);T02(3, 4)];
  p2p =[T02p(1, 4); T02p(2, 4);T02p(3, 4)]; 
  p3 = [T03(1, 4); T03(2, 4);T03(3, 4)];
  p4 = [T04(1,4); T04(2,4);T04(3, 4)];
  p4x = [T04(1, 1);T04(2, 1);T04(3, 1)];
  p4y = [T04(1, 2);T04(2, 2);T04(3, 2)];
  p4z = [T04(1, 3);T04(2, 3);T04(3, 3)];
  %draw links
  plot3([p0(1), p1(1)], [p0(2), p1(2)],[p0(3),p1(3)], '-b', 'LineWidth', 3); %link1
  plot3([p1(1), p2(1)], [p1(2), p2(2)],[p1(3),p2(3)], '-b', 'LineWidth', 3); %link2
  plot3([p2(1), p2p(1)], [p2(2), p2p(2)],[p2(3),p2p(3)], '-b', 'LineWidth', 3); %link2p
  plot3([p2p(1), p3(1)], [p2p(2), p3(2)],[p2p(3),p3(3)], '-b', 'LineWidth', 3); %link3
  plot3([p3(1), p4(1)], [p3(2), p4(2)],[p3(3),p4(3)], '-b', 'LineWidth', 3); %link4
  %draw joints
  plot3([p0(1), p0(1)], [p0(2), p0(2)],[p0(3), p0(3)], 'or', 'LineWidth', 3);
  plot3([p1(1), p1(1)], [p1(2), p1(2)],[p1(3), p1(3)], 'or', 'LineWidth', 3);
  plot3([p2(1), p2(1)], [p2(2), p2(2)],[p2(3), p2(3)], 'or', 'LineWidth', 3);
  plot3([p2p(1), p2p(1)], [p2p(2), p2p(2)],[p2p(3), p2p(3)], 'or', 'LineWidth', 3);
  plot3([p3(1), p3(1)], [p3(2), p3(2)],[p3(3), p3(3)], 'or', 'LineWidth', 3);
  plot3([p4(1), p4(1)], [p4(2), p4(2)],[p4(3), p4(3)], 'or', 'LineWidth', 3);
  %tool axis
  plot3([p4(1),p4(1)+p4x(1)*7],[p4(2),p4(2)+p4x(2)*7],[p4(3),p4(3)+p4y(3)], '-c', 'LineWidth', 2);%tool x
  plot3([p4(1),p4(1)+p4y(1)*7],[p4(2),p4(2)+p4y(2)*7],[p4(3),p4(3)+p4y(3)], '-g', 'LineWidth', 2);%tool y
  plot3([p4(1),p4(1)+p4z(1)*7],[p4(2),p4(2)+p4z(2)*7],[p4(3),p4(3)+p4z(3)*2], '-m', 'LineWidth', 2);%tool z
  %Trackposition
end