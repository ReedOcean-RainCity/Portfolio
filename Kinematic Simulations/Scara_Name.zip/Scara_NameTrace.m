%letter key point coordinates **note all letters finsih 5 units on z axisL
L = [[2,2,2,3,3];
     [4,4,2,2,2];
     [5,0,0,0,5]];
E = [[5,5,4,4,5,4,4,5,5];
     [4,4,4,3,3,3,2,2,2];
     [5,0,0,0,0,0,0,0,5]];
O = [[6,6,6,7,7,6,7,7];
     [2,2,4,4,2,2,2,2];
     [5,0,0,0,0,0,0,5]];
N = [[8,8,8,9,9,9];
     [2,2,4,2,4,4];
     [5,0,0,0,0,5]];

x = [L(1,:),E(1,:),O(1,:),N(1,:)];
y = [L(2,:),E(2,:),O(2,:),N(2,:)];
z = [L(3,:),E(3,:),O(3,:),N(3,:)];
L1 = 10;
L2 = 6;
L3 = 6;
alpha = 0;

travTime = 3;

b = numel(x);
pp = 1*10**(-10);

t1 = [];
t2 = [];
t4 = [];
pEE = [];

for i=1:b
  if i==1
    t1I = 0;
    t2I = 0;
    t4I = 0;
  else
    t1I = t1(i-1);
    t2I = t2(i-1);
    t4I = t4(i-1);
  endif
  [t1F,t2F,t4F,d4] = Scara_IK(L1,L2,L3,alpha,x(i),y(i),z(i));
  [t1A0,t1A2,t1A3] = calcTrajCo(t1F,t1I,travTime);
  [t2A0,t2A2,t2A3] = calcTrajCo(t2F,t2I,travTime);
  [t4A0,t4A2,t4A3] = calcTrajCo(t4F,t4I,travTime);
  t1(i) = t1F;
  t2(i) = t2F;
  t4(i) = t4F;
  k=1; %whole number iterator for second loop
  for j=1:0.1:travTime
    t1m = t1A0+(t1A2*j^2)+(t1A3*j^3);
    t2m = t2A0+(t2A2*j^2)+(t2A3*j^3);
    t4m = t4A0+(t4A2*j^2)+(t4A3*j^3);
    [T01,T02,T02p,T03,T04] = Scara_DK(L1,L2,L3,d4,t1m,t2m,t4m);
    DrawScara(T01,T02,T02p,T03,T04,pEE);
    figure(1);
    hold on;
    p3 = [T03(1, 4); T03(2, 4);T03(3, 4)];
    pEE = [pEE, p3];
    plot3(pEE(1, :), pEE(2, :),pEE(3,:), '.r', 'LineWidth', 10);
    k+=1;
    pause(pp);
  end;
end;